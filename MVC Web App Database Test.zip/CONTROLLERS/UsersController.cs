using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using $safeprojectname$.Data;
using $safeprojectname$.Models;

namespace $safeprojectname$.Controllers
{
    public class UsersController : Controller
    {
        private readonly AppDBContext appDBContext;

        public UsersController(AppDBContext context)
        {
            appDBContext = context;
        }

        public async Task<IActionResult> Index()
        {
            var users = await appDBContext.Users.ToListAsync();
            return View(users);
        }

        [HttpPost]
        public async Task<IActionResult> CreateUser(User user)
        {
            appDBContext.Add(user);
            await appDBContext.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public IActionResult CreateUser()
        {
            return View();
        }
    }
}